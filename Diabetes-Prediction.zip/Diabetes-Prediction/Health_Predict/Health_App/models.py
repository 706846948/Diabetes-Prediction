from django.db import models

# Create your models here.
class user(models.Model):
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=30)
    gender = models.BooleanField()
    age = models.IntegerField()
    height = models.IntegerField()
    weight = models.FloatField()

class personal(models.Model):
    name=models.CharField(max_length=30)
    gender = models.BooleanField()
    tel=models.IntegerField()
    email = models.EmailField()
    birthday = models.CharField(max_length=30)
    place = models.CharField(max_length=50)
    u_id = models.ForeignKey(user, on_delete='cascade')

class medical(models.Model):
    Glucose=models.FloatField()
    BloodPressure=models.FloatField()
    SkinThickness=models.FloatField()
    Insulin=models.FloatField()
    BMI = models.FloatField()
    DiabetesPedigreeFunction = models.FloatField()
    Date= models.CharField(max_length=30)
    u_id=models.ForeignKey(user,on_delete='cascade')


