# -*- coding:utf-8 -*-
import requests
import re
from requests.exceptions import RequestException
import json
from multiprocessing import Pool
from hashlib import md5
import os

# 爬取papers，papers包括文章的title, date, text, link

def get_one_page(url):
    try:
        reponse = requests.get(url)
        # 请求页面请求的编码方式
        print(reponse.encoding)
        # 页面指定的编码方式
        print(reponse.apparent_encoding)
        content = reponse.text.encode(reponse.encoding).decode(reponse.apparent_encoding,'ignore')
        # print(reponse.content)
        # print(content)
        # 200表示请求成功，HTTP状态码，表
        # 示网络请求成功的意思
        # ，返回这个状态表示已经获取到数据了
        if reponse.status_code == 200:
            return content
        else:
            return None
    except RequestException:
        return None

def parse_one_page(html,num):

    print("parse_one_page")
    # pattern = re.compile('<img.*?src="(.*?)".*?alt="(.*?)".*?/>',re.S)
    pattern = re.compile('<li>.*?<a.*?"title">(.*?)</a>.*?<small>'
                         '(.*?)</small>.*?<p.*?"intro">(.*?)<a.*?href="(.*?)".*?</p>.*?</li>', re.S)
    items = re.findall(pattern, html)
    for item in items:
        num=num+1
        print(type(item))
        yield {
            'number':num,
            'title': item[0],
            'date': item[1],
            'text': item[2],
            'link': "http://www.tnbz.com"+item[3]
        }

def write_to_file(content):
    with open('result.txt','a',encoding='utf-8') as f:
        f.write(json.dumps(content,ensure_ascii=False) + '\n')
        f.close()


def main(offset,n):
    # 文章路径
    if offset==1:
        url = "http://www.tnbz.com/a/erxing/index.html"
    else:
        url = "http://www.tnbz.com/a/erxing/index_"+str(offset)+".html"
    # 获取整个界面文本
    html = get_one_page(url)
    # 用相关的正则表达式对文本进行筛选，找出有用信息
    for item in parse_one_page(html,n):
        print(item)
        # 将筛选后的文本写入文件中储存
        write_to_file(item)
    # print(html)

if __name__ == '__main__':
    n=0
    for i in range(1,6):
        main(i,n)
        n = n + 25
