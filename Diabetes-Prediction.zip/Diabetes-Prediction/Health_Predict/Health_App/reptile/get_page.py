import requests
import re
from requests.exceptions import RequestException
import json

# 获取所要生成的文章的html
def get_one_page(url):
    try:
        reponse = requests.get(url)
        # 请求页面请求的编码方式
        print(reponse.encoding)
        # 页面指定的编码方式
        print(reponse.apparent_encoding)
        content = reponse.text.encode(reponse.encoding).decode(reponse.apparent_encoding,'ignore')
        # print(reponse.content)
        # print(content)
        # 200表示请求成功，HTTP状态码，表
        # 示网络请求成功的意思
        # ，返回这个状态表示已经获取到数据了
        if reponse.status_code == 200:
            return content
        else:
            return None
    except RequestException:
        return None

def parse_one_page(html,num):
    print("parse_one_page")
    # pattern = re.compile('<img.*?src="(.*?)".*?alt="(.*?)".*?/>',re.S)
    pattern = re.compile('<!-- /place -->(.*?)<!-- /viewbox -->', re.S)
    items = re.findall(pattern, html)
    for item in items:
        print(type(item))
        yield {
            'number':num,
            'html': item
        }

def write_to_file(content):
    with open('result_html.txt','a',encoding='utf-8') as f:
        f.write(json.dumps(content,ensure_ascii=False) + '\n')
        f.close()


def main(num,url):
    # main(offset):
    # url = "https://maoyan.com/board/4?offset=" + str(offset)
    # if offset==1:
    #     url = "http://www.tnbz.com/a/erxing/index.html"
    # else:
    #     url = "http://www.tnbz.com/a/erxing/index_"+str(offset)+".html"
    html = get_one_page(url)
    print(html)
    for item in parse_one_page(html,num):
        print(item)
        write_to_file(item)
    # print(html)

def loadDataSet():
    '''
        对于testSet.txt，每行前两个值分别是X1和X2，第三个值数据对应的类别标签
        而且为了设置方便，该函数还将X0的值设置为1.0
        :return:
        '''
    filename="result.txt"
    file = open(filename,"r",encoding='UTF-8')
    title = []
    date = []
    text = []
    link = []
    number=[]
    for line in file.readlines():
        test_config = json.loads(line)
        number.append(test_config["number"])
        title.append(test_config["title"])
        date.append(test_config["date"])
        text.append(test_config["text"])
        link.append(test_config["link"])
    print(len(title))
    print(number)
    # return test_config
    return number,title, date, text, link

if __name__ == '__main__':
    number,title, date, text, link = loadDataSet()
    for l in zip(number,link):
        main(l[0],l[1])

# title, date, text, link = loadDataSet()
# for l in link:
#     print(l)