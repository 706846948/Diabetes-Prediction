# coding:utf-8
import webbrowser
import json

# 生成html文件
def generate(html,index):
    # 命名和存放生成的html
    GEN_HTML = "../../templates/article/article"+index+".html"
    # 打开文件，准备写入
    f = open(GEN_HTML, 'w',encoding='UTF-8')
    # 准备相关变量

    # 写入HTML界面中
    message = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Title</title>
    </head>
    <body>
    <div>%s</div>
    <div >
    <a href="/push.html" class="n2">
    <span class="content-source">[返回]</span>
    </a>
    </div>
    </body>
    </html>
    """ % (html)
    print("")
    # 写入文件
    f.write(message)
    # 关闭文件
    f.close()

    # 运行完自动在网页中显示
    # webbrowser.open(GEN_HTML, new=1)


def loadDataSet():
    '''
        对于testSet.txt，每行前两个值分别是X1和X2，第三个值数据对应的类别标签
        而且为了设置方便，该函数还将X0的值设置为1.0
        :return:
        '''
    filename="result_html.txt"
    file = open(filename,"r",encoding='UTF-8')
    html = []
    number = []
    for line in file.readlines():
        test_config = json.loads(line)
        html.append(test_config["html"])
        number.append(test_config["number"])
    print(html)
    # return test_config
    return html,number


# generate()
# loadDataSet()
html,number = loadDataSet()
index=0
for html in zip(html,number):
    generate(html[0],str(html[1]))