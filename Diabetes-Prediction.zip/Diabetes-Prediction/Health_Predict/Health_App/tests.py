import matplotlib.pyplot as plt
import numpy as np
import json
from Health_App import models


new_data=models.medical.objects.all().order_by("-id")[:7]

# for new in new_data:
#     print(new)