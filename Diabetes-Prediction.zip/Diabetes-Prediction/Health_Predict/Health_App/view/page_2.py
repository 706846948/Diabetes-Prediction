from django.shortcuts import render
from django.shortcuts import redirect
from django.shortcuts import HttpResponse
from Health_App import models
from matplotlib.pyplot import MultipleLocator
import datetime
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
import numpy as np
from Health_App.logistic.logistic import predict


def main_show(request):
    if request.method == 'GET':
        nid = request.GET.get("nid")
    return render(request, "./page_2/../../templates/page_2/main_show.html", locals())


def show_table(request):
    medical_list = models.medical.objects.all()
    Glucose = []
    BloodPressure = []
    Insulin = []
    BMI = []
    Date = []
    path_tendency1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\total_tendency_Glucose.png"
    path_tendency2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\total_tendency_BloodPressure.png"
    path_tendency3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\total_tendency_Insulin.png"
    path_tendency4 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\total_tendency_BMI.png"
    for row in medical_list:
        #打印各个参数
        print(row.Date,row.Glucose, row.BloodPressure, row.SkinThickness, row.Insulin,
              row.BMI,row.DiabetesPedigreeFunction)
        Glucose.append(row.Glucose)
        BloodPressure.append(row.BloodPressure)
        Insulin.append(row.Insulin)
        BMI.append(row.BMI)
        Date.append(row.Date)
    max1,min1=draw_tendency("Date", "Glucose", Date, Glucose, "yellow", path_tendency1, "Glucose-tendency", 0.5,True)
    gap1=max1-min1
    max2,min2=draw_tendency("Date", "BloodPressure", Date, BloodPressure, "red", path_tendency2, "BloodPressure-tendency", 10,True)
    gap2=max2-min2
    max3,min3=draw_tendency("Date", "Insulin", Date, Insulin, "blue", path_tendency3, "Insulin-tendency", 2,True)
    gap3=max3-min3
    max4,min4=draw_tendency("Date", "BMI", Date, BMI, "green", path_tendency4, "BMI-tendency", 5,True)
    gap4=max4-min4
    return render(request, "page_2/../../templates/page_2/show_table.html", locals())



def main_exhibition(request):
    if request.method == 'GET':
        nid = request.GET.get("nid")
    print("main_exhibition:",nid)

    # new_data = models.medical.objects.all().order_by("-id")[:7]
    # print(type(new_data))
    # for new in new_data:
    #     print(new.Date)

    path1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\Glucose.png"
    path2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\BloodPressure.png"
    path3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\Insulin.png"
    path4 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\BMI.png"
    Glucose = []
    BloodPressure = []
    Insulin = []
    BMI = []
    Date = []
    G = models.medical.objects.all().values("Glucose")
    BP = models.medical.objects.all().values("BloodPressure")
    I = models.medical.objects.all().values("Insulin")
    BM = models.medical.objects.all().values("BMI")
    Da = models.medical.objects.all().values("Date")
    for g in G:
        Glucose.append(g['Glucose'])
    for bp in BP:
        BloodPressure.append(bp['BloodPressure'])
    for i in I:
        Insulin.append(i['Insulin'])
    for bm in BM:
        BMI.append(bm['BMI'])
    for da in Da:
        Date.append(da['Date'])
    # print(Glucose, BloodPressure, Insulin, BMI, Date)
    draw_tendency("Date", "Glucose", Date, Glucose, "yellow", path1, "Glucose-tendency", 0.5)
    draw_tendency("Date", "BloodPressure", Date, BloodPressure, "red", path2, "BloodPressure-tendency", 10)
    draw_tendency("Date", "Insulin", Date, Insulin, "blue", path3, "Insulin-tendency", 2)
    draw_tendency("Date", "BMI", Date, BMI, "green", path4, "BMI-tendency", 0.5)
    return render(request, 'page_2/../../templates/page_2/main_exhibition.html', locals())

def exhibition(request):
    # 画趋势图
    path1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\Glucose.png"
    path2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\BloodPressure.png"
    path3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\Insulin.png"
    path4 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\BMI.png"
    Glucose = []
    BloodPressure = []
    Insulin = []
    BMI = []
    Date = []
    G = models.medical.objects.all().values("Glucose")
    BP = models.medical.objects.all().values("BloodPressure")
    I = models.medical.objects.all().values("Insulin")
    BM = models.medical.objects.all().values("BMI")
    Da = models.medical.objects.all().values("Date")
    for g in G:
        Glucose.append(g['Glucose'])
    for bp in BP:
        BloodPressure.append(bp['BloodPressure'])
    for i in I:
        Insulin.append(i['Insulin'])
    for bm in BM:
        BMI.append(bm['BMI'])
    for da in Da:
        Date.append(da['Date'])
    # print(Glucose, BloodPressure, Insulin, BMI, Date)
    draw_tendency("Date", "Glucose", Date, Glucose, "yellow", path1, "Glucose-tendency", 0.5)
    draw_tendency("Date", "BloodPressure", Date, BloodPressure, "red", path2, "BloodPressure-tendency", 10)
    draw_tendency("Date", "Insulin", Date, Insulin, "blue", path3, "Insulin-tendency", 2)
    draw_tendency("Date", "BMI", Date, BMI, "green", path4, "BMI-tendency", 0.5)
    return render(request, 'page_2/exhibition.html')



def main_analysis(request):
    if request.method == 'GET':
        nid = request.GET.get("nid")
    return render(request,"page_2/main_analysis.html",locals())


def analysis(request):
    # 画直方图
    path1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\Analysis_Glucose.png"
    path2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\Analysis_BP.png"
    path3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\Analysis_Insulin.png"
    path4 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\Analysis_BMI.png"
    Glucose = []
    BloodPressure = []
    Insulin = []
    BMI = []
    G = models.medical.objects.all().values("Glucose")
    BP = models.medical.objects.all().values("BloodPressure")
    I = models.medical.objects.all().values("Insulin")
    BM = models.medical.objects.all().values("BMI")
    Da = models.medical.objects.all().values("Date")
    for g in G:
        Glucose.append(g['Glucose'])
    for bp in BP:
        BloodPressure.append(bp['BloodPressure'])
    for i in I:
        Insulin.append(i['Insulin'])
    for bm in BM:
        BMI.append(bm['BMI'])
    print(Glucose,BloodPressure,Insulin,BMI)
    a1, b1, c1, d1 =draw_histogram("Glucose",Glucose, "yellow",path1,['<3.9', '3.9-6.1', '6.1-6.7','>=6.7'],[3.9,6.1,6,7])
    e1 = c1 / (a1 + b1 + c1 + d1)
    a2, b2, c2, d2 =draw_histogram("BloodPressure",BloodPressure,"red",path2,['90', '90-120', '120-140','>=140'],[90,120,140])
    e2 = c2 / (a2 + b2 + c2 + d2)
    a3, b3, c3, d3 =draw_histogram("Insulin",Insulin, "blue",path3, ['35', '35-90', '90-145','>=145'],[35,90,145])
    e3 = c3 / (a3 + b3 + c3 + d3)
    # return HttpResponse("...")
    return render(request, 'page_2/analysis.html',locals())



def main_head(request):
    if request.method == 'GET':
        nid = request.GET.get("nid")
    return render(request,"page_2/main_head.html",locals())

def head_report(request):
    return render(request,"page_2/head_report.html")

def main_week(request):
    if request.method == 'GET':
        nid = request.GET.get("nid")
    return render(request, "page_2/main_week.html",locals())

def weekly_report(request):
    med_list = models.medical.objects.all().order_by("-id")[:7]
    Glucose = []
    BloodPressure = []
    Insulin = []
    BMI = []
    Date = []
    # med_list = models.medical.objects.all()
    for row1 in med_list:
        print(row1.Date, row1.Glucose, row1.BloodPressure, row1.SkinThickness, row1.Insulin,
              row1.BMI, row1.DiabetesPedigreeFunction)
        Glucose.append(row1.Glucose)
        BloodPressure.append(row1.BloodPressure)
        Insulin.append(row1.Insulin)
        BMI.append(row1.BMI)
        Date.append(row1.Date)
    path_tendency1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\week_tendency_Glucose.png"
    path_tendency2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\week_tendency_BloodPressure.png"
    path_tendency3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\week_tendency_Insulin.png"
    path_tendency4 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\week_tendency_BMI.png"

    path_histogram1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\week_histogram_Glucose.png"
    path_histogram2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\week_histogram_BloodPressure.png"
    path_histogram3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\week_histogram_Insulin.png"

    path_abnormal1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\week_Abnormal_situation.png"
        # print(Glucose, BloodPressure, Insulin)
    type = ("Glucose", "BloodPressure", "Insulin")
    max1, min1 = draw_tendency("Date", "Glucose", Date, Glucose, "yellow", path_tendency1, "Glucose-tendency", 0.5,False)
    gap1 = max1 - min1
    max2, min2 = draw_tendency("Date", "BloodPressure", Date, BloodPressure, "red", path_tendency2, "BloodPressure-tendency", 10,False)
    gap2 = max2 - min2
    max3, min3 = draw_tendency("Date", "Insulin", Date, Insulin, "blue", path_tendency3, "Insulin-tendency", 2,False)
    gap3 = max3 - min3
    max4, min4 = draw_tendency("Date", "BMI", Date, BMI, "green", path_tendency4, "BMI-tendency", 5,False)
    gap4 = max4 - min4

    a1, b1, c1, d1=draw_histogram("Glucose", Glucose, "yellow", path_histogram1, ['<3.9', '3.9-6.1', '6.1-6.7', '>=6.7'], [3.9, 6.1, 6, 7])
    e1 = c1 / (a1 + b1 + c1 + d1)
    a2, b2, c2, d2=draw_histogram("BloodPressure", BloodPressure, "red", path_histogram2, ['90', '90-120', '120-140', '>=140'], [90, 120, 140])
    e2 = c2 / (a2 + b2 + c2 + d2)
    a3, b3, c3, d3=draw_histogram("Insulin", Insulin, "blue", path_histogram3, ['35', '35-90', '90-145', '>=145'], [35, 90, 145])
    e3 = c3 / (a3 + b3 + c3 + d3)

    precent_g,precent_b ,precent_i=draw_abnormal(type, Glucose, BloodPressure, Insulin, "red", path_abnormal1, "total-abnormalities", "%",7)

    databetes_data = get_medical(7)
    predict_value = predict(databetes_data)
    ultimate_value = judge(predict_value)
    # return HttpResponse("...")
    print("databetes_data",databetes_data)
    # print("predict",predict_value)
    return render(request,"page_2/weekly_report.html",locals())

def main_month(request):
    if request.method == 'GET':
        nid = request.GET.get("nid")
    return render(request, "page_2/main_month.html",locals())
    # return render(request, "page_2/main_week.html")
    # return HttpResponse("...")

def monthly_report(request):
    med_list = models.medical.objects.all().order_by("-id")[:30]
    Glucose2 = []
    BloodPressure2 = []
    Insulin2 = []
    BMI2=[]
    Date2=[]
    # med_list = models.medical.objects.all()
    for row2 in med_list:
        print(row2.Date, row2.Glucose, row2.BloodPressure, row2.SkinThickness, row2.Insulin,
              row2.BMI, row2.DiabetesPedigreeFunction)
        Glucose2.append(row2.Glucose)
        BloodPressure2.append(row2.BloodPressure)
        Insulin2.append(row2.Insulin)
        BMI2.append(row2.BMI)
        Date2.append(row2.Date)

    path_tendency1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\month_tendency_Glucose.png"
    path_tendency2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\month_tendency_BloodPressure.png"
    path_tendency3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\month_tendency_Insulin.png"
    path_tendency4 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\month_tendency_BMI.png"

    path_histogram1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\month_histogram_Glucose.png"
    path_histogram2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\month_histogram_BloodPressure.png"
    path_histogram3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\month_histogram_Insulin.png"

    path_abnormal2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\month_Abnormal_situation.png"

    # print(Glucose, BloodPressure, Insulin)
    type = ("Glucose", "BloodPressure", "Insulin")
    max1, min1 = draw_tendency("Date", "Glucose", Date2, Glucose2, "yellow", path_tendency1, "Glucose-tendency", 0.5,True)
    gap1 = max1 - min1
    max2, min2 = draw_tendency("Date", "BloodPressure", Date2, BloodPressure2, "red", path_tendency2,"BloodPressure-tendency", 10, True)
    gap2 = max2 - min2
    max3, min3 = draw_tendency("Date", "Insulin", Date2, Insulin2, "blue", path_tendency3, "Insulin-tendency", 2, True)
    gap3 = max3 - min3
    max4, min4 = draw_tendency("Date", "BMI", Date2, BMI2, "green", path_tendency4, "BMI-tendency", 5, True)
    gap4 = max4 - min4
    a1, b1, c1, d1 =draw_histogram("Glucose", Glucose2, "yellow", path_histogram1, ['<3.9', '3.9-6.1', '6.1-6.7', '>=6.7'],[3.9, 6.1, 6, 7])
    e1 = c1 / (a1 + b1 + c1 + d1)
    a2, b2, c2, d2 =draw_histogram("BloodPressure", BloodPressure2, "red", path_histogram2, ['90', '90-120', '120-140', '>=140'],[90, 120, 140])
    e2 = c2 / (a2 + b2 + c2 + d2)
    a3, b3, c3, d3 =draw_histogram("Insulin", Insulin2, "blue", path_histogram3, ['35', '35-90', '90-145', '>=145'], [35, 90, 145])
    e3 = c3 / (a3 + b3 + c3 + d3)
    precent_g, precent_b, precent_i =draw_abnormal(type, Glucose2, BloodPressure2, Insulin2, "blue", path_abnormal2, "total-abnormalities", "%",30)
    databetes_data = get_medical(30)
    predict_value = predict(databetes_data)
    ultimate_value = judge(predict_value)
    # return HttpResponse("...")
    # print("databetes_data", databetes_data)
    # print("predict",predict_value)
    return render(request,"page_2/monthly_report.html",locals())

def main_quarter(request):
    if request.method == 'GET':
        nid = request.GET.get("nid")
    return render(request, "page_2/main_quarter.html",locals())

def quarterly_report(request):
    med_list = models.medical.objects.all().order_by("-id")[:90]
    Glucose3 = []
    BloodPressure3 = []
    Insulin3 = []
    BMI3 = []
    Date3 = []
    # med_list = models.medical.objects.all()
    for row3 in med_list:
        print(row3.Date, row3.Glucose, row3.BloodPressure, row3.SkinThickness, row3.Insulin,
              row3.BMI, row3.DiabetesPedigreeFunction)
        Glucose3.append(row3.Glucose)
        BloodPressure3.append(row3.BloodPressure)
        Insulin3.append(row3.Insulin)
        BMI3.append(row3.BMI)
        Date3.append(row3.Date)

    path_tendency1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\quarter_tendency_Glucose.png"
    path_tendency2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\quarter_tendency_BloodPressure.png"
    path_tendency3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\quarter_tendency_Insulin.png"
    path_tendency4 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\quarter_tendency_BMI.png"

    path_histogram1 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\quarter_histogram_Glucose.png"
    path_histogram2 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\quarter_histogram_BloodPressure.png"
    path_histogram3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\quarter_histogram_Insulin.png"

    path_abnormal3 = r"C:\Users\Administrator\Desktop\资料\A_edit\Health_Predict\static\images\quarter_Abnormal_situation.png"

    # print(Glucose, BloodPressure, Insulin)
    type = ("Glucose", "BloodPressure", "Insulin")
    max1, min1 =draw_tendency("Date", "Glucose", Date3, Glucose3, "yellow", path_tendency1, "Glucose-tendency", 0.5,True)
    gap1=max1-min1
    max2, min2 =draw_tendency("Date", "BloodPressure", Date3, BloodPressure3, "red", path_tendency2, "BloodPressure-tendency", 10,True)
    gap2 = max2 - min2
    max3, min3 =draw_tendency("Date", "Insulin", Date3, Insulin3, "blue", path_tendency3, "Insulin-tendency", 2,True)
    gap3 = max3 - min3
    max4, min4 =draw_tendency("Date", "BMI", Date3, BMI3, "green", path_tendency4, "BMI-tendency", 5,True)
    gap4 = max4 - min4

    a1, b1, c1, d1 =draw_histogram("Glucose", Glucose3, "yellow", path_histogram1, ['<3.9', '3.9-6.1', '6.1-6.7', '>=6.7'],[3.9, 6.1, 6, 7])
    e1 = c1 / (a1 + b1 + c1 + d1)
    a2, b2, c2, d2 =draw_histogram("BloodPressure", BloodPressure3, "red", path_histogram2, ['90', '90-120', '120-140', '>=140'],[90, 120, 140])
    e2 = c2 / (a2 + b2 + c2 + d2)
    a3, b3, c3, d3 =draw_histogram("Insulin", Insulin3, "blue", path_histogram3, ['35', '35-90', '90-145', '>=145'], [35, 90, 145])
    e3 = c3 / (a3 + b3 + c3 + d3)
    precent_g, precent_b, precent_i =draw_abnormal(type, Glucose3, BloodPressure3, Insulin3, "yellow", path_abnormal3, "total-abnormalities", "%",90)
    databetes_data = get_medical(90)
    predict_value = predict(databetes_data)
    ultimate_value = judge(predict_value)
    # return HttpResponse("...")
    # print("databetes_data", databetes_data)
    # print("predict",predict_value)
    return render(request, "page_2/quarterly_report.html", locals())


def draw_tendency(xlabel,ylabel,x,y,color,path,title,space,flag):
    min=y[0]
    max=y[0]
    for item in y:
        if min>item:
            min=item
        if max <item:
            max=item
    plt.title(title)
    plt.ylabel(ylabel)
    fig, ax = plt.subplots()
    ax.set_xlabel(xlabel)
    ax.set_ylabel('value')
    ax.set_title(xlabel + ' by frequency')
    # 把x轴的刻度范围设置为-0.5到11，因为0.5不满一个刻度间隔，所以数字不会显示出来，但是能看到一点空白
    plt.plot(x, y, color)
    if flag:
        plt.xticks([])
    plt.savefig(path)
    fig.tight_layout()
    plt.close()
    return max,min


def draw_histogram(label,datas,color,path,labels,section):
    Glucose_means = []
    a=0
    b=0
    c=0
    d=0

    for item in datas:
        if item<section[0]:
            a+=1
        elif item>=section[0] and item< section[1] :
            b+=1
        elif item>=section[1] and item< section[2]:
            c+=1
        else:
            d+=1
    Glucose_means=[a,b,c,d]

    x = np.arange(len(labels))
    width = 0.35  # 柱状条宽度
    fig, ax = plt.subplots()
    '''
    fig, ax = plt.subplots()
    等价于：
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)'''

    rects1 = ax.bar(x - width/2, Glucose_means, width, label=label,color=color)
    # Add some text for labels, title and custom x-axis tick labels, etc.
    ax.set_ylabel('value')
    ax.set_title(label+' by frequency')
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend()
    fig.tight_layout()
    plt.savefig(path)
    # plt.show()
    return a,b,c,d


def draw_abnormal(type,Glucose,BloodPressure,Insulin,color,path,title,xlabel,num):
        sum_g = 0
        sum_b = 0
        sum_i = 0
        # print(Glucose, BloodPressure, Insulin)
        for g in Glucose:
            # print("g",g)
            if g >= 3.9 and g < 6.1:
                sum_g += 1
        for b in BloodPressure:
            # print("b",b)
            if b >= 90 and b < 140:
                sum_b += 1
        for i in Insulin:
            # print("i",i)
            if i >= 35 and i < 145:
                sum_i += 1
        precent_g = ((num - sum_g) * 100) // num
        precent_b = round((num - sum_b) * 100) // num
        precent_i = round((num - sum_i) * 100) // num
        print("分子",sum_g, sum_b, sum_i)
        print("分母",len(Glucose), len(BloodPressure), len(Insulin))
        g_percent = ((len(Glucose)-sum_g)/ len(Glucose))*100
        b_percent = ((len(BloodPressure)-sum_b)/ len(BloodPressure))*100
        i_percent = ((len(Insulin)-sum_i)/ len(Insulin))*100
        plt.rcdefaults()
        fig, ax = plt.subplots()
        # y_pos刻度值
        y_pos = np.arange(len(type))
        performance = [g_percent, b_percent, i_percent]
        # performance是五个值的列表
        print(performance)
        #  bar() 函数来绘制柱状图 ，barh() 函数可以生成水平柱状图
        ax.barh(y_pos, performance, align='center', color=color)
        # y_pos是[0 1 2 3 4]五个刻度
        ax.set_yticks(y_pos)
        # people定义了五个标签
        ax.set_yticklabels(type)
        # 标签自上而下读取
        ax.invert_yaxis()
        ax.set_xlabel(xlabel)
        ax.set_title(title)
        plt.savefig(path)
        plt.close()
        return precent_g,precent_b,precent_i

def get_medical(index):
    med_list = models.medical.objects.all().order_by("-id")[:index]
    A = models.user.objects.all().values("age")
    Glucose = []
    BloodPressure = []
    Insulin = []
    SkinThickness = []
    BMI = []
    DiabetesPedigreeFunction = []
    Age = []
    diabetes = []

    for row in med_list:
        print(row.Date, row.Glucose, row.BloodPressure, row.SkinThickness, row.Insulin,
              row.BMI, row.DiabetesPedigreeFunction)
        Glucose.append(row.Glucose)
        BloodPressure.append(row.BloodPressure)
        Insulin.append(row.Insulin)
        SkinThickness.append(row.SkinThickness)
        BMI.append(row.BMI)
        DiabetesPedigreeFunction.append(row.DiabetesPedigreeFunction)
        for a in A:
            Age.append(a['age'])
    # print(Glucose, BloodPressure, SkinThickness, Insulin, BMI, DiabetesPedigreeFunction,Age)
    for item in range(len(Glucose)):
        diabetes.append([1,float(Glucose[item]), float(BloodPressure[item]),float(SkinThickness[item]),
                         float(Insulin[item]),float(BMI[item]),float(DiabetesPedigreeFunction[item]),
                        float(Age[item])])
    # print(diabetes)
    return diabetes

def judge(predict_data):
    one=0
    zero=0
    for i in predict_data:
        if i==1:
            one+=1
        else:
            zero+=1
    # print("one:",one,"zero:",zero)
    if zero>one:
        return 0
    elif zero==one:
        return 0.5
    else:
        return 1
