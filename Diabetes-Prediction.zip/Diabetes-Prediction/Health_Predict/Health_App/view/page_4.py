from django.shortcuts import render
from django.shortcuts import redirect
from django.shortcuts import HttpResponse
from Health_App import models
from matplotlib.pyplot import MultipleLocator
import datetime
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
import numpy as np


def main_personal(request):
    if request.method == 'GET':
        nid = request.GET.get("nid")
    print("main_personal nid:",nid)
    return render(request, "page_4/main_personal.html",locals())


def personal(request):
    id = 1
    if request.method == 'GET':
        nid = request.GET.get("nid")
        obj = models.personal.objects.filter(id=id).first()
        # print("name",obj.name)
        return render(request, "page_4/personal.html",locals())

    elif request.method == "POST":
        nid = request.GET.get("nid")
        n = request.POST.get('name')
        g = request.POST.get('gender')
        t = request.POST.get('tel')
        e = request.POST.get('email')
        b = request.POST.get('birthday')
        p = request.POST.get('place')
        print("personal nid:",nid)
        obj = models.personal.objects.filter(id=id).first()
        models.personal.objects.filter(id=id).update(name=n, gender=g,tel=t, email=e,
                                                     birthday=b,place=p,u_id=nid)
        return render(request,'page_4/personal.html',locals())

