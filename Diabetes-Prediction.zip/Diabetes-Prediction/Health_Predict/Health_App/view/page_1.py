from django.shortcuts import render
from django.shortcuts import redirect
from django.shortcuts import HttpResponse
from Health_App import models
from matplotlib.pyplot import MultipleLocator
import datetime
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt



def main_input(request):
    if request.method == 'GET':
        nid = request.GET.get("nid")
        print("main_input nid:",nid)
    return render(request, 'page_1/main_input.html',locals())

def input(request):
    if request.method=='GET':
        nid = request.GET.get("nid")
        print("input_nid:",nid)
        # return HttpResponse("...")
        return render(request, "page_1/input.html",locals())
    elif request.method=='POST':
        nid = request.GET.get('nid')
        Glucose = request.POST.get('Glucose')
        BloodPressure = request.POST.get('BloodPressure')
        SkinThickness = request.POST.get('SkinThickness')
        Insulin = request.POST.get('Insulin')
        BMI = request.POST.get('BMI')
        DiabetesPedigreeFunction = request.POST.get('DiabetesPedigreeFunction')

        print(Glucose,BloodPressure,SkinThickness,Insulin,BMI,DiabetesPedigreeFunction,nid)
        models.medical.objects.create(
            Glucose=Glucose,
            BloodPressure = BloodPressure,
            SkinThickness = SkinThickness,
            Insulin = Insulin,
            BMI = BMI,
            DiabetesPedigreeFunction = DiabetesPedigreeFunction,
            Date = time(),
            u_id = models.user.objects.filter(id=nid).first()
        )
        return render(request, "page_1/input.html", locals())
        # return redirect("/input.html",locals())

def time():
    curr_time=datetime.datetime.now()
    year = curr_time.year
    month=curr_time.month
    day=curr_time.day
    time=str(year)+'-'+str(month)+'-'+str(day)
    print(time)
    return time

def main_get(request):
    if request.method == 'GET':
        nid = request.GET.get("nid")
    return render(request, "./page_1/../../templates/page_1/main_get.html", locals())


def get_table(request):
    medical_list = models.medical.objects.all()
    for row in medical_list:
        #打印各个参数
        print(row.Date,row.Glucose, row.BloodPressure, row.SkinThickness, row.Insulin,
              row.BMI,row.DiabetesPedigreeFunction)
    return render(request, "page_1/../../templates/page_1/get_table.html", locals())

def edit_data(request):
    if request.method == 'GET':
        nid = request.GET.get('nid')
        obj = models.medical.objects.filter(id=nid).first()
        # obj中有当前学生的班级ID=2  obj.cs_id
        # 所有班级ID   班级名称
        #   1          1班
        #   2          2班 selected
        # cls_list是什么类型？QuerySet相当于列表
        # 【{'id':'cc',title:'xx'},{'id':'',title:'xx'},】
        # for row in cls_list:
        #     print(row['id'])
        return render(request, "page_1/../../templates/page_1/edit_data.html", {'obj': obj})
    elif request.method == "POST":
        # ,Glucose,BloodPressure,SkinThickness,Insulin,BMI,DiabetesPedigreeFunction
        nid = request.GET.get('nid')
        G = request.POST.get('Glucose')
        BP = request.POST.get('BloodPressure')
        S = request.POST.get('SkinThickness')
        I = request.POST.get('Insulin')
        BMI = request.POST.get('BMI')
        D = request.POST.get('DiabetesPedigreeFunction')
        models.medical.objects.filter(id=nid).update(Glucose=G, BloodPressure=BP,
                                                     SkinThickness=S, Insulin=I,BMI=BMI,
                                                     DiabetesPedigreeFunction=D)
        return redirect('/get_table.html')