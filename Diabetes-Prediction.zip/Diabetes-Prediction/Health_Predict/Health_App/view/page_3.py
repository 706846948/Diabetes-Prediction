from django.shortcuts import render
from django.shortcuts import redirect
from django.shortcuts import HttpResponse
from Health_App import models
from matplotlib.pyplot import MultipleLocator
import datetime
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
import numpy as np
import json



def main_push(request):
    return render(request,"../templates/page_3/main_push.html")


def push(request):
    papers = loadDataSet()
    # print(title, date, text, link)
    # for i in papers:
    #     print(i["title"])
    #     print(i["date"])
    #     print(i["text"])
    #     print(i["link"])
    return render(request,"../templates/page_3/push.html",locals())


def loadDataSet():

    filename="result.txt"
    file = open(filename,"r",encoding='UTF-8')
    papers=[]
    # title = []
    # date = []
    # text = []
    # link = []
    for line in file.readlines():
        test_config = json.loads(line)
        papers.append(test_config)
        # title.append(test_config["title"])
        # date.append(test_config["date"])
        # text.append(test_config["text"])
        # link.append(test_config["link"])
    # print(len(title))
    print(papers[0])
    # return test_config
    return papers

def article(request):
    if request.method == "GET":
        index=request.GET.get("article")
    return render(request,"../templates/article/article"+index+".html")