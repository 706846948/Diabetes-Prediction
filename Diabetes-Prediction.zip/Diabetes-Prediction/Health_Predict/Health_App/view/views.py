from django.shortcuts import render
from django.shortcuts import redirect
from django.shortcuts import HttpResponse
from Health_App import models
from matplotlib.pyplot import MultipleLocator
import datetime
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt

# Create your views here.


def register(request):
    if request.method=='GET':
        return render(request, "register.html")
    elif request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        gender = request.POST.get('gender')
        age = request.POST.get('age')
        height = request.POST.get('height')
        weight = request.POST.get('weight')

        print(username,password,age,height,weight,gender)
        models.user.objects.create(
            username = username,
            password= password,
            gender=gender,
            age = age,
            height = height,
            weight = weight
       )
        return redirect('/login.html')

def login(request):
    user = request.GET.get('user')
    pwd = request.GET.get('password')
    ret = models.user.objects.filter(username=user).values('id','password')
    for item in ret:
        nid=item['id']
        print("login:",nid)
        if(item['password']==pwd):
            return render(request, 'main.html',locals())
        else:
            return HttpResponse('用户名或密码错误')

    return render(request, 'login.html')



def main(request):
    return render(request, 'main.html')


def test(request):

    # Da = models.personal.objects.all().values('birthday')
    # print(Da)
    # for da in Da:
    #     print(da['birthday'])
    # print(Date)
    # e =request.POST.get('username')
    # print(e)
    models.personal.objects.create(name='小东北', gender=True,  tel=15373281426,
                                   email='3158797486@qq.com',birthday='2020-05-08',place='北京',u_id_id=1)
    # models.user.objects.create(username='程晨',password=153732,  gender=True, age=32,
    #                                height=165, weight=56.6)
    return HttpResponse("...")