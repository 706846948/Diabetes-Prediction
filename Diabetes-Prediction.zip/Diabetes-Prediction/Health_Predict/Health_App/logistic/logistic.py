# _*_coding:utf-8_*_
from numpy import *
import csv


# 读取数据
def loadDataSet(filename):
    '''
        对于testSet.txt，每行前两个值分别是X1和X2，第三个值数据对应的类别标签
        而且为了设置方便，该函数还将X0的值设置为1.0
        :return:
        '''
    dataMat = []
    labelMat = []
    fr = open(filename)
    for line in fr.readlines():
        lineArr = line.strip().split(',')
        dataMat.append([1,float(lineArr[0]), float(lineArr[1]),float(lineArr[2]),
                        float(lineArr[3]),float(lineArr[4]),float(lineArr[5]),float(lineArr[6])])
        labelMat.append(int(lineArr[7]))
    weights=gradAscent(dataMat, labelMat)
    # return dataMat, labelMat
    return weights,dataMat, labelMat


def gradAscent(dataMatIn, classLabels):
    '''
        :param dataMatIn: 是一个2维Numpy数组，每列分别代表每个不同的特征
        每行则代表每个训练样本。
        :param classLabels: 是类别标签，是一个1*100的行向量，为了便于矩阵运算，需要将行向量
        转换为列向量，就是矩阵的转置，再将其赋值与labelMat。
        :return:
        '''
    dataMatrix = mat(dataMatIn)
    labelMat = mat(classLabels).transpose()
    # labelMat = mat(classLabels).T
    m, n = shape(dataMatrix)
    print("m:",m," n:",n)
    # alpha是向目标移动的步长
    alpha = 0.001
    # 迭代次数
    maxCycles = 500
    weights = ones((n, 1))
    for k in range(maxCycles):
        h = sigmoid(dataMatrix * weights)
        error = (labelMat - h)
        weights = weights + alpha * dataMatrix.transpose() * error
    return weights


def predict(data):
    filename = 't_t.txt'
    weight,dataMat, labelMat = loadDataSet(filename)
    y_list = []
    for item in data:
        y_predict=sigmoid(item*weight)
        if y_predict>=0.5:
            y_predict=1
        else:
            y_predict=0
        y_list.append(y_predict)
    # print("y_list",y_list)
    return y_list

def sigmoid(inX):
    i=1.0 / (1 + exp(-inX))
    # print("i:",i)
    return i

#计算准确率
def correct(predict,label):
    correct=0
    for i in range(len(predict)):
        # print("predict",predict[i])
        if predict[i]==label[i]:
            correct+=1

    return correct,len(predict)

# SSR, SSE, SST, R_2
def RR(pre,label):
    SSR = 0
    SST = 0
    SSE = 0
    length=len(label)
    # 计算复相关系数：
    y_sum = 0
    # 求和
    for item in label:
        y_sum = float(item) + y_sum
    y_average = y_sum / length
    # print(y_average)

    for i in range(len(label)):
        y_fact = float(label[i])
        y_predict = pre[i]
        # print(y_fact)
        SSR = (y_predict - y_average) ** 2 + SSR
        SSE = (y_fact - y_predict) ** 2 + SSE
    SST = SSR + SSE
    R_2 = SSR / SST
    return SSR,SSE,SST,R_2


if __name__  == '__main__':
    filename = 't_t.txt'
    # weights,dataMat, labelMat = loadDataSet(filename)
    # print("weights",weights)
    # weights_res = gradAscent(dataArr,labelMat)
    # weights_res=loadDataSet(filename)
    predict_value=predict([[1,132,0,0,0,32.9,0.302,23]])
    # c,l=correct(predict_value,labelMat)
    # SSR, SSE, SST, R_2= RR(predict_value,labelMat)
    # R_adjust = 1 - ((1 - R_2) * (470 - 1)) / (470 - 1 - 1)
    print("predict_value:",predict_value[0])
    # print("labelMat", labelMat)
    # print(weights_res)
    # print("correct:",c)
    # print("准确率：{:.2f}%".format(100 * c / l))
    # print("SSR",SSR)
    # print("SSE",SSE)
    # print("SST",SST,)
    # print("决定系数：",R_2)
    # print("调整后决定系数：",R_adjust)

