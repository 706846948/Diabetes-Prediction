from django.apps import AppConfig


class HealthAppConfig(AppConfig):
    name = 'Health_App'
