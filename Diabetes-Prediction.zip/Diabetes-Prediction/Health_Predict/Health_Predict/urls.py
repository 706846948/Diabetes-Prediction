"""Health_Predict URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from Health_App.view import views,page_1,page_2,page_3,page_4

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^register.html$', views.register),
    url(r'^login.html$', views.login),
    url(r'^main.html$', views.main),
    url(r'^test.html$', views.test),
    # page_1
    url(r'^main_input.html$',page_1.main_input),
    url(r'^input.html$',page_1.input),
    url(r'^get_table.html$', page_1.get_table),
    url(r'^main_get.html$', page_1.main_get),
    url(r'^edit_data.html$', page_1.edit_data),
    # page_2
    url(r'^exhibition.html$', page_2.exhibition),
    url(r'main_exhibition.html$',page_2.main_exhibition),
    url(r'show_table.html$',page_2.show_table),
    url(r'^main_show.html$',page_2.main_show),
    url(r'^analysis.html$',page_2.analysis),
    url(r'^main_analysis.html$',page_2.main_analysis),
    url(r'^head_report.html$', page_2.head_report),
    url(r'^main_head.html$', page_2.main_head),
    url(r'^weekly_report.html$',page_2.weekly_report),
    url(r'^main_week.html$', page_2.main_week),
    url(r'^monthly_report.html$',page_2.monthly_report),
    url(r'^main_month.html$', page_2.main_month),
    url(r'^quarterly_report.html$',page_2.quarterly_report),
    url(r'^main_quarter.html$', page_2.main_quarter),
    #page3
    url(r'^push.html$', page_3.push),
    url(r'^main_push.html$', page_3.main_push),
    url(r'^article', page_3.article),
    #page_4
    url(r'^personal.html$', page_4.personal),
    url(r'^main_personal.html$',page_4.main_personal),

]