from numpy import genfromtxt
import numpy as np
from sklearn import linear_model
import matplotlib.pyplot as plt
import csv

datapath=r"../Knn/Remove_dying.csv"
# datapath = "diabetes_t_t.csv"
#
datas = genfromtxt(datapath,delimiter=",",encoding="utf-8")
# print(datas)
length = len(datas)

n=length//3
test_set = datas[1:n]
train_set = datas[n:]
# print("test",len(test_set))

def MLR(test):


    x = train_set[1:,2:-1]  # 前为行，后为列 =[1:最后（行），]
    y = train_set[1:,-1]
    # for i in x:
    #     print("x:",i)
    # print("x:")
    # print(x)
    # print("y:")
    # print(y)

    mlr = linear_model.LinearRegression()
    # fix(X,y[,sample_weight])#：训练模型。
    mlr.fit(x, y)

    # print(mlr)
    # print("coef:")
    # #提取指定变量前的参数
    # print (mlr.coef_) #从b1开始到bp，不包括b0(截距)
    # print ("intercept")
    # print (mlr.intercept_)

    xPredict =  [test[2:-1]]  #没有行和列的切片，就一个的话，默认为列的切片
    yPredict = mlr.predict(xPredict)[0]

    # print ("predict:")
    # print (yPredict)
    return yPredict





correct =0
for test in test_set:
    result=int(test[-1])
    result2=int(MLR(test))  #csv文件保存字符串类型
    if (result2 > 0.5):
        result2=1
    else:
        result2=0
    if result==result2:
        correct+=1
print("correct:",correct,"准确率：{:.2f}%".format(100 * correct / len(test_set)))


#计算复相关系数：
y_sum=0
# 求和
for item in datas[2:]:
    y_sum=float(item[-1])+y_sum
y_average=y_sum/length
# print(y_average)

# 求实际值和估计值
SSR=0
SST=0
SSE=0

for item1 in datas[2:]:
    y_fact=float(item[-1])
    y_predict=MLR(item1)
    # print(y_fact)
    SSR=(y_predict-y_average)**2+SSR
    SSE=(y_fact-y_predict)**2+SSE
SST=SSR+SSE
R_2=SSR/SST
R_adjust=1-((1-R_2)*(471-1))/(471-1-1)
print("SSR：",SSR)
print("SST：",SST)
print("决定系数：",R_2)
print("调整后决定系数：",R_adjust)
