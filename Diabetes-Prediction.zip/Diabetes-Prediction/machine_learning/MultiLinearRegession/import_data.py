import pandas
import csv, sqlite3
conn= sqlite3.connect('data_diabetes')
df = pandas.read_csv('diabetes.csv')
df.to_sql('app01_diabetes', conn, if_exists='append', index=False)
cursor = conn.cursor()
cursor.execute("select name from sqlite_master where type='app01_diabetes' order by name")
print (cursor.fetchall())
[('app01_diabetes',)]
cursor.execute("select * from app01_diabetes")
col_name_list = [tuple[0] for tuple in cursor.description]
print (col_name_list)
# 执行查询语句:
cursor.execute('select * from app01_diabetes ')
# 获得查询结果集:
values = cursor.fetchall()
# 遍历打印输出
for smile in values:
    print(smile)

# import pandas
# import csv, sqlite3
# conn= sqlite3.connect("data_diabetes.db")
# df = pandas.read_csv('diabetes.csv')
# df.to_sql('app01_diabetes', conn, if_exists='append', index=False)
# print('ok')
