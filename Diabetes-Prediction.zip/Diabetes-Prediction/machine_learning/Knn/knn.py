import csv
import random
###
#算法原理
#   1.通用步骤
#         计算距离(常用欧几里得距离或马氏距离)
#         升序排列
#         取前K个
#         加权平均
#     2.k的选取
#         K太大：导致分类模糊
#         K太小：受个例影响
#     3.如何选取K
#         经验
#         均方根误差
###



with open('Prostate_Cancer.csv','r') as file:
    reader =csv.DictReader(file)
    datas=[row for row in reader]

#打乱顺序
random.shuffle(datas)

# 分组 /除  //整除，向下取整
n=len(datas)//3

#前三分之一做做测试集(10%)，后三分之二做训练集(90%)
test_set=datas[0:n]
train_set=datas[n:]

# Knn距离
def distance(d1,d2):
    res=0;
      # 这里没有加上"id", "diagnosis_result" ，不然会包 could not convert string to float: 'M
    for key in ("radius","texture","perimeter","area","smoothness","compactness","symmetry","fractal_dimension"):
        res+=(float(d1[key])-float(d2[key]))**2

    return res**0.5



K=7
def knn(data):
    #1.距离
    res=[
        {"result":train['diagnosis_result'],"distance":distance(data,train)}
        for train in train_set
    ]
    # print(res)

    #2.排序--升序
    res=sorted(res,key=lambda item:item['distance'])
    # print(res)


    #3.取前K个
    res2=res[0:K]

    #4.加权平均
    result={'B':0,'M':0}  #初始B和M的权重为0

    # 总距离
    sum=0
    for r in res2:
        sum+=r['distance']

    for r in res2:
        result[r['result']]+=1-r['distance']/sum

    # print(result)
    # print(data['diagnosis_result'])

    if result['B']>result['M']:
        return 'B'
    else:
        return 'M'

# 测试阶段
correct=0
for test in test_set:
    result=test['diagnosis_result']
    result2 = knn(test)

    if result==result2:
        correct+=1

print("准确率：{:.2f}%".format(100*correct/len(test_set)))

knn(test_set[0])

