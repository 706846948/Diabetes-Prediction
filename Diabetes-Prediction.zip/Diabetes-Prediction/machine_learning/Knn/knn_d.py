import csv
import random
import numpy as np
from sklearn import linear_model
from numpy import genfromtxt
import matplotlib.pyplot as plt
###
#算法原理
#   1.通用步骤
#         计算距离(常用欧几里得距离或马氏距离)
#         升序排列
#         取前K个
#         加权平均
#     2.k的选取
#         K太大：导致分类模糊
#         K太小：受个例影响
#     3.如何选取K
#         经验
#         均方根误差
# csv文件增加一列并计数可借助excel
###



with open('../MultiLinearRegession/diabetes.csv','r') as file:
    reader =csv.DictReader(file)
    datas=[row for row in reader]
# print(datas)

#打乱顺序
random.shuffle(datas)

# 分组 /除  //整除，向下取整
# n=len(datas)/10  n=2000/10=200

#前三分之一做做测试集(30%)，后三分之二做训练集(70%)
test_set=datas[0:600]
train_set=datas[600:]
# print(train_set)


# Knn距离
def distance(d1,d2):
    res=0;
      # 这里没有加上"id", "diagnosis_result" ，不然会包 could not convert string to float: 'M
    for key in ("Pregnancies","Glucose","BloodPressure","SkinThickness","Insulin",
                "BMI","DiabetesPedigreeFunction","Age"):
        res+=(float(d1[key])-float(d2[key]))**2
    # print("欧氏距离：",res**0.5)
    return res**0.5

# K 10-44

def knn(data,K):
    #1.距离
    res=[
        {"result":train['Outcome'],"distance":distance(data,train)}
        for train in train_set
    ]
    # print(res)

    #2.排序--升序排列
    res=sorted(res,key=lambda item:item['distance'])
    # print(res)


    #3.取前K个
    res2=res[0:K]
    # print("res2=",res2)
    #4.加权平均
    result={'1':0,'0':0}  #初始B和M的权重为0

    # 总距离
    sum = 0
    for r in res2:
        sum+=r['distance']
        # print("sum=",sum)
        # print("distance",r['distance'])
    for r in res2:
        # 若k值选取过小时，可能会出现测试集的前k个与给定样本重合导致sum之和为0
        result[r['result']]+=1-r['distance']/sum
    # print(result)
    # print(data['Outcome'])

    if result['1']>result['0']:
        return '1'
    else:
        return '0'


def convert_csv(train_set):
    #写覆盖
        with open('convert.csv', 'w',newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=["ID","Pregnancies","Glucose","BloodPressure",
                "SkinThickness","Insulin","BMI","DiabetesPedigreeFunction","Age","Outcome"])
            # 写入列标题，即DictWriter构造方法的fieldnames参数
            writer.writeheader()
            for row in train_set:
                writer.writerow({'ID':row['ID'],'Pregnancies':row['Pregnancies'], 'Glucose':row['Glucose'],'BloodPressure':row['BloodPressure'],
                        'SkinThickness':row['SkinThickness'],'Insulin':row['Insulin'],'BMI':row['BMI'],'DiabetesPedigreeFunction':row['DiabetesPedigreeFunction'],
                        'Age':row['Age'],'Outcome':row['Outcome']})


def Mlr():
    datapath=r'../Knn/convert.csv'
    data1 = genfromtxt(datapath, delimiter=",", encoding="utf-8")
    # print(data1)
    x=data1[1:,1:-1]
    y=data1[1:,-1]
    # 建立多元回归模型
    mlr=linear_model.LinearRegression()
    mlr.fit(x,y)

    print(mlr)
    print("coef:")
    #提取指定变量前的参数
    print (mlr.coef_) #从b1开始到bp，不包括b0(截距)，回归参数
    print ("intercept")
    print (mlr.intercept_)#指b0，权重向量

    # 输入特征以及输出目标
    xPredict =  [[6,148,72,35,0,33.6,0.627,50]]
    yPredict = mlr.predict(xPredict)

    print ("predict:")
    print (yPredict)

    if(yPredict>0.5):
        print("1")
    else:
        print("0")

#  画图
# 定义画图数据
Pregnancies = []
Glucose = []
BloodPressure = []
SkinThickness = []
Insulin= []
BMI = []
DiabetesPedigreeFunction= []
Age = []
Outcome = []

# 定义绘图数据
def get_data(filename):
    with open(filename,'r') as csvfile:
        csvFileReader = csv.reader(csvfile)
        next(csvFileReader)
        for row in csvFileReader:
            Pregnancies.append(int(row[1]))
            Glucose.append(int(row[2]))
            BloodPressure.append(int(row[3]))
            SkinThickness.append(int(row[4]))
            Insulin.append(int(row[5]))
            BMI.append(float(row[6]))
            DiabetesPedigreeFunction.append(float(row[7]))
            Age.append(int(row[8]))
            Outcome.append(int(row[9]))
    return


def show_plot(date, result):
    linear_mod = linear_model.LinearRegression()
    date = np.reshape(date, (len(date), 1))  # 转换为n x 1的矩阵
    result = np.reshape(result, (len(result), 1))
    linear_mod.fit(date, result)  # 在模型中拟合数据点
    plt.scatter(date, result, color='yellow')  # 绘制初始数据点
    plt.plot(date, linear_mod.predict(date), color='blue', linewidth=3)  # 绘制线性回归线
    plt.savefig(r'C:\Users\Administrator\Desktop\资料\A_edit\machine_learning\picture\picture.png')
    plt.show()
    return

def kvalue_Accuracy(a,b):
    b=b/600;
    with open('Kvale_Accuracy.csv', 'a+', newline='') as csvfile:
        writer = csv.writer(csvfile)
        # 写入列标题，即DictWriter构造方法的fieldnames参数
        data=[a,b]
        writer.writerow(data)


# knn(test_set[0])
# convert_csv(train_set)
# Mlr()
# get_data('../MultiLinearRegession/diabetes.csv')
# show_plot(Pregnancies,Outcome)
# show_plot(Glucose,Outcome)
# show_plot(BloodPressure,Outcome)
# show_plot(SkinThickness,Outcome)
# show_plot(Insulin,Outcome)
# show_plot(BMI,Outcome)
# show_plot(DiabetesPedigreeFunction,Outcome)
# show_plot(Age,Outcome)
# 测试阶段
# for K in range(6,10):
# for x in range(10):
K=10
correct=0
random.shuffle(datas)
test_set = datas[0:600]
train_set = datas[600:]
for test in test_set:
    result=test['Outcome']

    result2 = knn(test,K)
    # print(result2)
    if result==result2:
        # print(test)
        #筛选数据
        with open('Remove_dying.csv', 'a+', newline='') as csvfile:
            # 写入列标题，即DictWriter构造方法的fieldnames参数
            writer = csv.DictWriter(csvfile, fieldnames=["ID", "Pregnancies", "Glucose", "BloodPressure",
                                                         "SkinThickness", "Insulin", "BMI",
                                                         "DiabetesPedigreeFunction",
                                                         "Age", "Outcome"])
            with open('Remove_dying.csv', 'r', newline='') as f:
                reader=csv.reader(f)
                if not [row for row in reader]:
                    writer = csv.DictWriter(csvfile, fieldnames=["ID", "Pregnancies", "Glucose", "BloodPressure",
                                                                 "SkinThickness", "Insulin", "BMI",
                                                                 "DiabetesPedigreeFunction",
                                                                 "Age", "Outcome"])

                    writer.writeheader()
                    writer.writerow({'ID': test['ID'], 'Pregnancies': test['Pregnancies'], 'Glucose': test['Glucose'],
                                 'BloodPressure': test['BloodPressure'],
                                 'SkinThickness': test['SkinThickness'], 'Insulin': test['Insulin'], 'BMI': test['BMI'],
                                 'DiabetesPedigreeFunction': test['DiabetesPedigreeFunction'],
                                 'Age': test['Age'], 'Outcome': test['Outcome']})
                else:
                    writer.writerow({'ID': test['ID'], 'Pregnancies': test['Pregnancies'], 'Glucose': test['Glucose'],
                                     'BloodPressure': test['BloodPressure'],
                                     'SkinThickness': test['SkinThickness'], 'Insulin': test['Insulin'],
                                     'BMI': test['BMI'],
                                     'DiabetesPedigreeFunction': test['DiabetesPedigreeFunction'],
                                     'Age': test['Age'], 'Outcome': test['Outcome']})
                f.close()


        correct+=1
#   {:.2f}精确到小数点后两位
print("K值为：",K,"准确率：{:.2f}%".format(100 * correct / len(test_set)))

kvalue_Accuracy(K,correct)

