import numpy as np
import matplotlib.pyplot as plt

# Fixing random state for reproducibility

dt = 0.1
t = np.arange(0, 30, dt)

s1 = np.sin(2 * np.pi * 10 * t)
s2 = np.sin(2 * np.pi * 20 * t)
s3 = np.sin(2 * np.pi * 30 * t)

fig, axs = plt.subplots(1, 1)
s = s1 + s2 + s3
plt.plot(t, s)
plt.savefig(r'C:\Users\Administrator\Desktop\资料\A_edit\machine_learning\picture\2.png')
plt.show()