import numpy as np
import matplotlib.pyplot as plt

# Fixing random state for reproducibility
# 确定再现性的随机状态
# numpy.random.seed(0) ; numpy.random.rand(4)
# numpy.random.seed(0)是的确定随机数的开始值相同
# numpy.random.rand(4)随机生成四个数
#设计一个随机数种子
np.random.seed(19680801)

#步长为0.1
dt = 0.01

'''
np.arange()函数分为一个参数，两个参数，三个参数三种情况
1）一个参数时，参数值为终点，起点取默认值0，步长取默认值1。
2）两个参数时，第一个参数为起点，第二个参数为终点，步长取默认值1。
3）三个参数时，第一个参数为起点，第二个参数为终点，第三个参数为步长。其中步长支持小数
'''
t = np.arange(0, 30, dt)

'''
numpy.random.rand()产生从[0,1) [0,1)[0,1)之间的随机数，没有负值
numpy.random.randn()产生服从正态分布的随机数，会出现负值
深度学习中的parameters是可能会有负值的，所以我们不使用numpy.random.rand()
'''
nse1 = np.random.randn(len(t))                 # white noise 1 白噪一
nse2 = np.random.randn(len(t))                 # white noise 2


# Two signals with a coherent part at 10Hz and a random part
# 2 * np.pi==2*pi
# np.sin(a)  对矩阵a中每一个元素取正弦
s1 = np.sin(2 * np.pi * 1 * t) + nse1
s2 = np.sin(2 * np.pi * 1 * t) + nse2

'''
ig,ax = plt.subplots()等价于：
fig = plt.figure()
ax = fig.add_subplot(1,1,1)
fig, ax = plt.subplots(1,3),其中参数1和3分别代表子图的行数和列数，
一共有 1x3 个子图像。函数返回一个figure图像和子图ax的array列表。
fig, ax = plt.subplots(1,3,1),最后一个参数1代表第一个子图。
如果想要设置子图的宽度和高度可以在函数内加入figsize值
fig, ax = plt.subplots(1,3,figsize=(15,7))，这样就会有1行3个15x7大小的子图。
'''
fig, axs = plt.subplots(2, 1)

'''
#单条线：
plot([x], y, [fmt], data=None, **kwargs)
#多条线一起画
plot([x], y, [fmt], [x2], y2, [fmt2], ..., **kwargs)
'''
# 两条曲线
# axs[0]表示第一个图
axs[0].plot(t, s1, t, s2)
# 设置x轴起始和结束坐标
axs[0].set_xlim(0, 2)
# x和y标签
axs[0].set_xlabel('time')
axs[0].set_ylabel('s1 and s2')
# grid(true)绘制刻度线的网格 False不绘制
axs[0].grid()

# axs[1]表示第二个图 dt为步长
# 绘制s1和s2 ，NNFT=256应该是默认参数
cxy, f = axs[1].cohere(s1, s2, 256, 1. / dt)
# 设置y坐标为相关性
axs[1].set_ylabel('coherence')

#tight_layout会自动调整子图参数，使之填充适应整个图像区域
fig.tight_layout()
# savefig()保存图片,如果有更新则重写图片
plt.savefig(r'C:\Users\Administrator\Desktop\资料\A_edit\machine_learning\picture\1.png')
plt.show()