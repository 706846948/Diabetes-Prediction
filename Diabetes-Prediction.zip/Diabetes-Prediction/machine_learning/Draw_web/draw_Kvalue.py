import csv
import numpy as np
from numpy import genfromtxt
from sklearn import linear_model
import matplotlib.pyplot as plt
# 定义绘图数据
#  画图
# 定义画图数据



# 可以借助cxcel统计计算平均值，然后将平均值导入draw_Kvalue.csv用于下面的绘图
K_value = []
Accuracy = []
def get_data(filename):
    with open(filename,'r') as csvfile:
        csvFileReader = csv.reader(csvfile)
        next(csvFileReader)
        for row in csvFileReader:
            K_value.append(int(row[0]))
            Accuracy.append(float(row[1]))
    return


def show_plot(date,result):
    linear_mod = linear_model.LinearRegression()
    date = np.reshape(date,(len(date),1)) # 转换为n x 1的矩阵
    result = np.reshape(result,(len(result),1))
    linear_mod.fit(date,result) #在模型中拟合数据点
    plt.scatter(date,result,color='yellow') #绘制初始数据点

    plt.plot(date[:,:4],result[:,:4],color='red')#绘制散点图
    plt.plot(date,linear_mod.predict(date),color='blue',linewidth=3) #绘制线性回归线
    plt.ylabel('Accuarcy')
    plt.xlabel('K_value')
    plt.title("K_value-Accuracy")
    plt.savefig('1.png')
    plt.show()
    return


get_data('draw_Kvalue.csv')
show_plot(K_value,Accuracy)