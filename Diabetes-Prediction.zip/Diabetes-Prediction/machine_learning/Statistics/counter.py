import csv
import numpy as np

with open(r'../Knn/Remove_dying.csv') as file:
    x_g_0 = 0;
    x_g_1 = 0;
    x_b_0 = 0;
    x_b_1 = 0;
    x_b_2 = 0;
    x_bm_0 = 0;
    x_bm_1 = 0;
    x_bm_2 = 0;
    x_bm_3 = 0;
    x_bm_4 = 0;
    x_a_0 = 0;
    x_a_1 = 0;
    x_a_2 = 0;
    x_a_3 = 0;
    x_a_4 = 0;
    x_a_5 = 0;
    x_a_6 = 0;
    x_o_0 = 0;
    x_o_1 = 0;

    reader = csv.reader(file)
    datas=[row for row in reader]
    diabetes = np.array(datas)
    # print(datas)
    #血糖、血压、体重指数、年龄
    Glucose=diabetes[1:,2:3]
    BloodPressure=diabetes[1:,3:4]
    BMI=diabetes[1:,6:7]
    Age=diabetes[1:,8:9]
    Outcome=diabetes[1:,-1]

    # 血糖大于7.0为糖尿病
    for item in Glucose:
        # print(item[0])
        if (int(item[0])/18)>7.0:
            x_g_0=x_g_0+1
        else:
            x_g_1+=1
    print("血糖大于7.0人数：",x_g_0,"百分比：",float(x_g_0/479))
    print("血糖小于7.0人数：", x_g_1,"百分比：",float(x_g_1/479))

    #血压以舒张压为准60-90
    for item in BloodPressure:
        if int(item[0])>60 and int(item[0])<90:
            x_b_0=x_b_0+1
        elif int(item[0])<60:
            x_b_1+=1
        else:
            x_b_2+=1
    print("血压小于60人数：",x_b_0,"百分比：",float(x_b_0/479))
    print("血压60-90人数：", x_b_1,"百分比：",float(x_b_1/479))
    print("血压大于90人数：", x_b_2,"百分比：",float(x_b_2/479))


    for item in BMI:
        if float(item[0])<=20.0:
            x_bm_0+=1
        elif float(item[0])>20.0 and float(item[0])<=25.0:
            x_bm_1+=1
        elif float(item[0])>25.0 and float(item[0])<=30.0:
            x_bm_2+=1
        elif float(item[0])>30.0 and float(item[0])<=35.0:
            x_bm_3+=1
        else :
            x_bm_4+=1

    print("体重指数小于20人数：", x_bm_0,"百分比：",float(x_bm_0/479))
    print("体重指数20-25人数：", x_bm_1,"百分比：",float(x_bm_1/479))
    print("体重指数25-30人数：", x_bm_2,"百分比：",float(x_bm_2/479))
    print("体重指数30-35人数：", x_bm_3,"百分比：",float(x_bm_3/479))
    print("体重指数大于35人数：", x_bm_4,"百分比：",float(x_bm_4/479))

    for item in Age:

        if int(item[0])<30:
            x_a_0+=1
        elif int(item[0])>30 and int(item[0])<=40:
            x_a_1+=1
        elif int(item[0])>40 and int(item[0])<=50:
            x_a_2+=1
        elif int(item[0])>50 and int(item[0])<=60:
            x_a_3+=1
        elif int(item[0])>60 and int(item[0])<=70:
            x_a_4+=1
        else :
            x_a_5+=1

    print("年龄小于30人数：", x_a_0,"百分比：",float(x_a_0/479))
    print("年龄30-40人数：", x_a_1,"百分比：",float(x_a_1/479))
    print("年龄40-50人数：", x_a_2,"百分比：",float(x_a_2/479))
    print("年龄50-60人数：", x_a_3,"百分比：",float(x_a_3/479))
    print("年龄60-70人数：", x_a_4,"百分比：",float(x_a_4/479))
    print("年龄大于70人数：", x_a_5,"百分比：",float(x_a_5/479))

    for item in Outcome:
        # print(item[0])
        if int(item[0])>0:
            x_o_0 = x_o_0 + 1
        else:
            x_o_1 += 1
    print("患病人数：", x_o_0, "百分比：", float(x_o_0 / 479))
    print("未患病人数：", x_o_1, "百分比：", float(x_o_1 / 479))






