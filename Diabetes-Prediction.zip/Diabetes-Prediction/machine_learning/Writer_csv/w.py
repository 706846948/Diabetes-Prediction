import csv

headers=['name','age']

datas=[{'name':'Bob','age':23},
       {'name':'Jerry','age':44},
       {'name':'Tom','age':15}
       ]
# open函数读写参数说明：
#
# w：以写方式打开，
# a：以追加模式打开 (从 EOF 开始, 必要时创建新文件)
# r+：以读写模式打开
# w+：以读写模式打开 (参见 w )
# a+：以读写模式打开 (参见 a )
# rb：以二进制读模式打开
# wb：以二进制写模式打开 (参见 w )
# ab：以二进制追加模式打开 (参见 a )
# rb+：以二进制读写模式打开 (参见 r+ )
# wb+：以二进制读写模式打开 (参见 w+ )
# ab+：以二进制读写模式打开 (参见 a+ )

with open('example.csv','w',newline='') as file:
    #写字典
    writer=csv.DictWriter(file,headers)
    writer.writeheader()
    for row in datas:
        writer.writerow(row)