# -*_coding:utf-8_*_
import math
from numpy import *


# Sigmoid函数的计算
def sigmoid(inX):
    return 1.0 / (1 + exp(-inX))


# 改进的随机梯度上升算法
def stocGradAscent1(dataMatrix, classLabels, numIter=150):
    m, n = shape(dataMatrix)
    weights = ones(n)
    for j in range(numIter):
        dataIndex = list(range(m))
        for i in range(m):
            alpha = 4 / (1.0 + j + i) + 0.01
            randIndex = int(random.uniform(0, len(dataIndex)))
            h = sigmoid(sum(dataMatrix[randIndex] * weights))
            error = classLabels[randIndex] - h
            weights = weights + alpha * error * dataMatrix[randIndex]
            del (dataIndex[randIndex])
    return weights


# Logistic回归分类函数
def classifyVetor(inX, weights):
    prob = sigmoid(sum(inX * weights))
    if prob > 0.5:
        return 1.0
    else:
        return 0.0


def colicTest(filetrain, filetest):
    frTrain = open(filetrain)
    frTest = open(filetest)
    trainingSet = []
    trainingLabeles = []
    for line in frTrain.readlines():
        # 删除字符开头和结尾的tab空格 '\t'代表tab
        currLine = line.strip().split(',')
        # print(currLine) #这里currLine类似csv格式文件 ,这里一共22种数据
        lineArr = []
        for i in range(7):
            #将currLine中保存的数据处理小数点后的位数
            #append()会在列表后加上相应元素，当列表为空时，可以看做是赋值
            lineArr.append(float(currLine[i]))
        # print(lineArr) #这里一共22种数据
        trainingSet.append(lineArr)
        # print(trainingSet)
        trainingLabeles.append(float(currLine[7]))
        # print(currLine[21])
    trainWeights = stocGradAscent1(array(trainingSet), trainingLabeles, 500)
    errorCount = 0
    numTestVec = 0
    for line in frTest.readlines():
        numTestVec += 1.0
        currLine = line.strip().split(',')
        lineArr = []
        for i in range(7):
            lineArr.append(float(currLine[i]))
        if int(classifyVetor(array(lineArr), trainWeights)) != int(currLine[7]):
            errorCount += 1
    errorRate = (float(errorCount) / numTestVec)
    print('the error rate of this test is  %f' % errorRate)
    return errorRate


def multTest(filetrain, filetest):
    numTests = 6
    errorSum = 1.0
    for k in range(numTests):
        errorSum += colicTest(filetrain, filetest)
    print(errorSum)
    print('after %d iterations  the average error rate is %f' % (numTests, errorSum / float(numTests)))


if __name__ == '__main__':
    #划分训练集和测试集
    # filetrain = 'horseColicTraining.txt'
    # filetest = 'horseColicTest.txt'
    filetrain = 'train.txt'
    filetest = 'test.txt'
    multTest(filetrain, filetest)