import numpy as np
import random
import math
from numpy import genfromtxt

#****需解决问题，数太大计算超时。

#非线性logistic 回归（正则化）

#梯度下降算法
#x和y分别是genData()中生成的一个矩阵和一列向量，
#theta带表w0、w1…wn
#alpha学习率
#m代表有多少个实列
#numIterations代表重复多少步，或者梯度下降法则走了多少步
def gradientDescent(x,y,theta,alpha,m,numIterations):
    #transpose将矩阵x转置
    xTran = np.transpose(x)
    #从0到numIterations
    for i in range(numIterations):
        # Z = Q0X0+Q1X1+Q2X2+...+QnXn
        # H(x) = i/(1+e^(-z))
        #dot()求内积函数，即x,theta的内积z=w*x
        hypothesis = np.dot(x,theta)
        print('hypothesis:',hypothesis)
        #loss代表预测值和实际值的查，即(h(x)-yi)
        loss = hypothesis-y
        # 将0和1的概率简化
        cost = np.sum(loss**2)/(2*m)
        # 更新法则:wj=wi-a*sum(h(x)-yi)*x  a代表theta学习率
        gradient=np.dot(xTran,loss)/m
        theta = theta-alpha*gradient
        # print ("Iteration %d | cost :%f" %(i,cost))
    return theta



# numpoints实例数 、bias偏差、variance平方
def genData():
    datapath = r"../Knn/Remove_dying.csv"
    # datapath = "Delivery.csv"
    datas = genfromtxt(datapath, delimiter=",", encoding="utf-8")
    #zeros()产生所有元素为0 numpoints 代表行数， 2 代表列数
    x = datas[1:,2:-1]
    #单独一个参数代表列，一列numpoints行
    y = datas[1:,-1]

    return x,y


x,y = genData()
print("x:")
print(x)
print("y:")
print(y)

# 将X中的 行数 列数給m n
m,n = np.shape(x)
n_y = np.shape(y)

print("m:"+str(m)+" n:"+str(n)+" n_y:"+str(n_y))
#
numIterations = 127
alpha = 0.0005
#ones(n) 初始n个1
theta = np.ones(n)
theta= gradientDescent(x, y, theta, alpha, m, numIterations)
# 将回归系数套入logistic公式中即可。
print("打印回归系数",theta)

# Glucose=x[:,0:1]
# BloodPressure=x[:,1:2]
# SkinThickness=x[:,2:3]
# Insulin=x[:,3:4]
# BMI=x[:,4:5]
# DiabetesPedigreeFunction=x[:,5:6]
# Age=x[:,-1]

# for item in x:
#     x1 = item[0]
#     x2 = item[1]
#     x3 = item[2]
#     x4 = item[3]
#     x5 = item[4]
#     x6 = item[5]
#     x7 = item[6]
#     y_predict = 1/(1+math.e**(-(x1*(-2.80089723000)+x2*(-1.5321239400)+x3*(-5.180626270)+
#                       x4*(-2.8429931200)+x5*(-7.124829180)+x6*(-1.1052591)+x7*(-7.013441430))*(1e+158)))
