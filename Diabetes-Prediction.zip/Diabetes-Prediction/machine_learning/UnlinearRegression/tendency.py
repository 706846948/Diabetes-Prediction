import matplotlib.pyplot as plt
from numpy import genfromtxt
import random

datapath = '../UnlinearRegression/tendency.csv'  # 文件所在位置，u为防止路径中有中文名称，此处没有，可以省略
# datapath = "Delivery.csv"
datas = genfromtxt(datapath,delimiter=",",encoding="utf-8")
random.shuffle(datas)
x=[]
for i in range(50):
    x.append(i)

Y_pred=datas[1:51,0:1]
Y_test=datas[1:51,-1]
plt.plot(x, Y_pred, 'green', linewidth=2.5, label="predict data")
plt.plot(x, Y_test, 'yellow', label="test data")
plt.legend(loc=2)
plt.savefig('logistic预测与实际值对比图.png')
plt.show()