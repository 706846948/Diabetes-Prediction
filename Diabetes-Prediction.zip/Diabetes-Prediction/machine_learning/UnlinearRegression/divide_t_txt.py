import csv


with open('../MultiLinearRegession/diabetes.csv','r') as file:
    reader =csv.DictReader(file)
    datas=[row for row in reader]

n=len(datas)
# test_set=datas[0:n]
train_set=datas[0:]

for test in train_set:
    with open('train.csv', 'a+', newline='') as csvfile:
        # 写入列标题，即DictWriter构造方法的fieldnames参数
        writer = csv.DictWriter(csvfile, fieldnames=["Glucose", "BloodPressure",
                                                 "SkinThickness", "Insulin", "BMI",
                                                 "DiabetesPedigreeFunction",
                                                     "Age", "Outcome"])
        with open('train.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            if not [row for row in reader]:
                writer = csv.DictWriter(csvfile, fieldnames=["Glucose", "BloodPressure",
                                                             "SkinThickness", "Insulin", "BMI",
                                                             "DiabetesPedigreeFunction",
                                                             "Age", "Outcome"])

                writer.writeheader()
                writer.writerow({'Glucose': test['Glucose'],
                                 'BloodPressure': test['BloodPressure'],
                                 'SkinThickness': test['SkinThickness'], 'Insulin': test['Insulin'], 'BMI': test['BMI'],
                                 'DiabetesPedigreeFunction': test['DiabetesPedigreeFunction'],
                                 'Age': test['Age'], 'Outcome': test['Outcome']})
            else:
                writer.writerow({'Glucose': test['Glucose'],
                                 'BloodPressure': test['BloodPressure'],
                                 'SkinThickness': test['SkinThickness'], 'Insulin': test['Insulin'],
                                 'BMI': test['BMI'],
                                 'DiabetesPedigreeFunction': test['DiabetesPedigreeFunction'],
                                 'Age': test['Age'], 'Outcome': test['Outcome']})
            f.close()